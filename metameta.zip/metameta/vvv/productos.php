<?php include("template/cabecera.php");?>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="css/cdmx.png" alt=""></img>
    
<div class="card-body">
        <h4 class="card-title">Universidades CDMX </h4>
        <a name="" id="" class="btn btn-primary" href="redes.php" role="button">INFORMATICA</a>
        <a name="" id="" class=></a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">INGENIERIA CIVIL</a>
        <a name="" id="" class=></a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">GESTION EMPRESARIAL</a>
        <a name="" id="" class=></a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">SISTEMAS COMPUTACIONALES</a>
        <a name="" id="" class=></a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">psicologia</a>
        <a name="" id="" class=></a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">administracion de empresas </a>
        
</div>

</div>

</div>





<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="" alt="">
    
<div class="card-body">
        <h4 class="card-title"> </h4>
       
        
</div>

</div>

</div>




<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="css/edomex1.png" alt="">
    
<div class="card-body">
        <h4 class="card-title">Universidades Edo.Mex.</h4>
        <a name="" id="" class="btn btn-primary" href="#" role="button">Medicina</a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">Veterinaria</a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">Derecho</a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">Mecanica</a>
        <a name="" id="" class="btn btn-primary" href="#" role="button">Programación</a>
</div>

</div>

</div>







<?php include("template/pie.php"); ?>