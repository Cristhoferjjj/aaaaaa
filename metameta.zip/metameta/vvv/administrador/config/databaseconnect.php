<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";
// create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
//check connection
if (!$conn) {
    die("Conecction failed: " . mysqli_connect_error());
mysql_close($conn);
?>
