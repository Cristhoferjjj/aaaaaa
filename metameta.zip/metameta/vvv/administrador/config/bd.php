<?php 
/*$host="localhost";

$dbname= 'login';
$nomcompl='usunombre';
$numtel='usunumtel';
$correo='usucorreo';*/

$bd="squad";
$usuario="root";
$contraseña="";
try {
       $conexion=new PDO("mysql:host=$host;dbname=$bd",$usuario,$contraseña);
    

 catch (Exception $ex) {
    
    echo $ex->getMessage();
}
?>